import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Server {

    public static void main(String[] args) {

        try {
            ServerSocket server = new ServerSocket(5000);

            System.out.println("Server Started...");
            System.out.println("Waiting for client...");

            Socket socket = server.accept();

            System.out.println("Client Connected!");

            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            Scanner sc = new Scanner(System.in);

            while (true) {

                String message = in.readUTF();

                if (message.equalsIgnoreCase("exit")) {
                    System.out.println("Client disconnected.");
                    break;
                }

                System.out.println("Client: " + message);

                System.out.print("Reply: ");
                String reply = sc.nextLine();

                out.writeUTF(reply);

                if (reply.equalsIgnoreCase("exit")) {
                    break;
                }
            }

            sc.close();
            in.close();
            out.close();
            socket.close();
            server.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}