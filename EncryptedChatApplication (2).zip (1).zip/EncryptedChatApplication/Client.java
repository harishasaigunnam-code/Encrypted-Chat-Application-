import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {

        try {

            Socket socket = new Socket("localhost", 5000);

            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            Scanner sc = new Scanner(System.in);

            while (true) {

                System.out.print("You: ");
                String message = sc.nextLine();

                out.writeUTF(message);

                if (message.equalsIgnoreCase("exit")) {
                    break;
                }

                String reply = in.readUTF();

                if (reply.equalsIgnoreCase("exit")) {
                    System.out.println("Server disconnected.");
                    break;
                }

                System.out.println("Server: " + reply);
            }

            sc.close();
            in.close();
            out.close();
            socket.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}